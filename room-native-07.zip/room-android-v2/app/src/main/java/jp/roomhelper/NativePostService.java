package jp.roomhelper;
import android.accessibilityservice.AccessibilityService;
import android.content.*;
import android.net.Uri;
import android.os.*;
import android.view.accessibility.*;
import org.json.*;
import java.util.*;
public class NativePostService extends AccessibilityService {
 private SharedPreferences prefs;private int scrolls;private boolean verified;private long lastScroll;private boolean gesturePending;
 private final java.util.concurrent.ExecutorService searchWorker=java.util.concurrent.Executors.newSingleThreadExecutor();
 private final Handler handler=new Handler(Looper.getMainLooper());
 private final Runnable loop=new Runnable(){public void run(){try{tick();}catch(Exception e){stop("画面操作エラー: "+e.getClass().getSimpleName());}handler.postDelayed(this,Timing.range(prefs==null?400:prefs.getInt("op_min_ms",400),prefs==null?1800:prefs.getInt("op_max_ms",1800)));}};
 @Override protected void onServiceConnected(){prefs=getSharedPreferences("native_queue",0);stop("操作サービス準備完了。開始を押すまで動きません");handler.post(loop);}
 private void stop(String s){prefs.edit().putBoolean("running",false).putString("status",s).commit();}
 private void phase(String p,String s){prefs.edit().putString("phase",p).putString("status",s).putLong("deadline",System.currentTimeMillis()+90000).commit();}
 private void advance() throws Exception {
  int next=prefs.getInt("index",0)+1;JSONArray queue=new JSONArray(prefs.getString("items","[]"));
  if(next>=queue.length()&&!prefs.getBoolean("auto_search",false)){stop("キュー処理終了。開始するまで停止します");return;}
  int min=prefs.getInt("min_wait_ms",prefs.getInt("min_wait",60)*1000),max=prefs.getInt("max_wait_ms",prefs.getInt("max_wait",180)*1000);if(min<100||max<min||max>3600000){stop("待ち時間の設定が不正です");return;}
  long delay=Timing.range(min,max);
  long until=System.currentTimeMillis()+delay;
  prefs.edit().putInt("index",next).putString("phase","interval").putLong("wait_until",until).putLong("deadline",until+90000).putString("status","次の商品まで約"+(delay/1000)+"秒。ロックすると停止します").commit();
 }
 private void refill() throws Exception {
  int calls=prefs.getInt("search_calls",0);if(calls>=30){stop("検索30回で候補を探し終えました。ワードを変更して再開してください");return;}
  String[] words=prefs.getString("search_words","ふるさと納税\n日用品\nスイーツ").split("\\n");
  int cursor=prefs.getInt("search_cursor",0),page=1+cursor/words.length;
  if(page>100){stop("検索ページ上限です");return;}
  String word=words[cursor%words.length].trim(),session=prefs.getString("session_id","");
  String template=prefs.getString("search_template","{name}\n商品の詳細はこちらから！\n#{keyword} #楽天市場");
  if(word.isEmpty()){stop("検索ワードが空です");return;}
  prefs.edit().putString("phase","searching").putInt("search_calls",calls+1).putInt("search_cursor",cursor+1).putLong("deadline",System.currentTimeMillis()+45000).putString("status","固定ワードで検索中："+word).commit();
  searchWorker.execute(()->{
   try {
    JSONArray response=RakutenSearch.fetch(this,word,page);java.util.List<JSONObject> candidates=new ArrayList<>();
    for(int i=0;i<response.length();i++){JSONObject item=response.getJSONObject(i);if(item.has("Item"))item=item.getJSONObject("Item");else if(item.has("item"))item=item.getJSONObject("item");candidates.add(item);}
    Collections.shuffle(candidates);
    JSONArray batch=new JSONArray();Set<String> seen=new HashSet<>();
    for(JSONObject product:candidates){
     String url=SearchPolicy.canonicalUrl(product.optString("itemUrl","")),name=product.optString("itemName","").trim();
     if(url==null||name.length()<3||product.optInt("availability",1)!=1||prefs.contains("attempt:"+url)||!seen.add(url))continue;
     String comment=SearchPolicy.render(template,name,word);if(comment.trim().isEmpty())continue;
     batch.put(new JSONObject().put("url",url).put("keyword",SearchPolicy.identifier(name)).put("comment",comment));
     if(batch.length()>=10)break;
    }
    handler.post(()->{
     if(!prefs.getBoolean("running",false)||!session.equals(prefs.getString("session_id","")))return;
     if(batch.length()==0){prefs.edit().putString("phase","interval").putLong("wait_until",System.currentTimeMillis()+2000).putLong("deadline",System.currentTimeMillis()+47000).putString("status","未処理の候補がないため次の検索を待っています").commit();return;}
     prefs.edit().putString("items",batch.toString()).putInt("index",0).putString("phase","launch").putLong("deadline",System.currentTimeMillis()+90000).putString("status",batch.length()+"件を自動補充しました").commit();
    });
   }catch(Exception e){handler.post(()->{if(prefs.getBoolean("running",false)&&session.equals(prefs.getString("session_id","")))stop("検索停止："+(e.getMessage()==null?e.getClass().getSimpleName():e.getMessage()));});}
  });
 }
 private String label(AccessibilityNodeInfo n){return n.getText()!=null?n.getText().toString().trim():n.getContentDescription()!=null?n.getContentDescription().toString().trim():"";}
 private void collect(AccessibilityNodeInfo n,List<AccessibilityNodeInfo> out){if(n==null||out.size()>1500)return;out.add(n);for(int i=0;i<n.getChildCount();i++)collect(n.getChild(i),out);}
 private boolean contains(List<AccessibilityNodeInfo> nodes,String token){for(AccessibilityNodeInfo n:nodes)if(n.isVisibleToUser()&&!n.isEditable()&&label(n).contains(token))return true;return false;}
 private AccessibilityNodeInfo exact(List<AccessibilityNodeInfo> nodes,String... labels){Set<AccessibilityNodeInfo> found=new HashSet<>();for(AccessibilityNodeInfo n:nodes)if(n.isVisibleToUser())for(String s:labels)if(s.equals(label(n))){AccessibilityNodeInfo c=n;for(int i=0;c!=null&&i<5;i++,c=c.getParent())if(c.isClickable()&&c.isEnabled()){found.add(c);break;}}return found.size()==1?found.iterator().next():null;}
 private boolean swipe(List<AccessibilityNodeInfo> nodes,AccessibilityNodeInfo root){
  android.graphics.Rect screen=new android.graphics.Rect();root.getBoundsInScreen(screen);
  android.graphics.Rect best=null;long area=0;
  for(AccessibilityNodeInfo n:nodes)if(n.isVisibleToUser()&&n.isScrollable()){
   android.graphics.Rect b=new android.graphics.Rect();n.getBoundsInScreen(b);
   if(!b.intersect(screen)||b.height()<300||b.width()<120)continue;
   long a=(long)b.width()*b.height();if(a>area){area=a;best=b;}
  }
  if(best==null)return false;
  float x=best.left+best.width()/2f;
  float start=best.top+best.height()*0.75f;
  float distance=best.height()*(Timing.range(250,450)/1000f);
  android.graphics.Path path=new android.graphics.Path();path.moveTo(x,start);path.lineTo(x,start-distance);
  android.accessibilityservice.GestureDescription gesture=new android.accessibilityservice.GestureDescription.Builder()
   .addStroke(new android.accessibilityservice.GestureDescription.StrokeDescription(path,0,Timing.range(250,650))).build();
  gesturePending=true;
  boolean accepted=dispatchGesture(gesture,new GestureResultCallback(){
   @Override public void onCompleted(android.accessibilityservice.GestureDescription g){gesturePending=false;}
   @Override public void onCancelled(android.accessibilityservice.GestureDescription g){gesturePending=false;if(prefs.getBoolean("running",false))stop("スクロールが中断されたため停止しました");}
  },handler);
  if(!accepted)gesturePending=false;
  return accepted;
 }
 private void tick()throws Exception{
  if(!prefs.getBoolean("running",false))return;android.os.PowerManager power=(android.os.PowerManager)getSystemService(POWER_SERVICE);android.app.KeyguardManager keyguard=(android.app.KeyguardManager)getSystemService(KEYGUARD_SERVICE);if(!power.isInteractive()||keyguard.isKeyguardLocked()){stop("画面ロックで停止しました");return;}if(System.currentTimeMillis()>prefs.getLong("deadline",0)){stop("画面確認がタイムアウト。ROOMで結果を確認してください");return;}
  if(gesturePending)return;
  JSONArray queue=new JSONArray(prefs.getString("items","[]"));int index=prefs.getInt("index",0);boolean publish=prefs.getBoolean("publish",false);
  if(publish&&!"result".equals(prefs.getString("phase",""))&&SearchPolicy.limitReached(prefs.getInt("session_attempts",0),prefs.getInt("session_limit",10))){stop("設定件数まで処理したため停止しました");return;}
  if(index>=queue.length()){
   if(!prefs.getBoolean("auto_search",false)){stop("キュー処理終了。開始するまで停止します");return;}
   if("interval".equals(prefs.getString("phase",""))){long left=prefs.getLong("wait_until",0)-System.currentTimeMillis();if(left>0){prefs.edit().putString("status","次の商品検索まで約"+((left+999)/1000)+"秒").apply();return;}}
   if(!"searching".equals(prefs.getString("phase","")))refill();return;
  }
  JSONObject item=queue.getJSONObject(index);String url=item.getString("url"),keyword=item.getString("keyword"),comment=item.getString("comment"),p=prefs.getString("phase","launch");
  if(p.equals("interval")){long left=prefs.getLong("wait_until",0)-System.currentTimeMillis();if(left>0){prefs.edit().putString("status","次の商品まで約"+((left+999)/1000)+"秒。停止・画面ロックで終了します").apply();return;}phase("launch","次の商品を開きます");return;}
  if(p.equals("launch")){if((publish&&prefs.contains("attempt:"+url))||"already_posted".equals(prefs.getString("attempt:"+url,""))){prefs.edit().putInt("index",index+1).commit();return;}Uri target=Uri.parse(url);if(!"https".equals(target.getScheme())||!"item.rakuten.co.jp".equals(target.getAuthority())||target.getPathSegments().size()!=2){stop("商品URL不一致");return;}scrolls=0;verified=false;lastScroll=0;phase("market",(index+1)+"/"+queue.length()+" 楽天市場アプリで商品を確認中");try{startActivity(new Intent(Intent.ACTION_VIEW,target).setPackage("jp.co.rakuten.android").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));}catch(ActivityNotFoundException e){stop("楽天市場アプリが見つかりません");}return;}
  AccessibilityNodeInfo root=getRootInActiveWindow();if(root==null)return;String pkg=root.getPackageName()==null?"":root.getPackageName().toString();if(!pkg.equals("jp.co.rakuten.android")&&!pkg.equals("com.rakuten.room"))return;
  List<AccessibilityNodeInfo> nodes=new ArrayList<>();collect(root,nodes);for(AccessibilityNodeInfo n:nodes)if(n.isPassword()){stop("ログインを本人が行ってください");return;}if(contains(nodes,"認証コード")||contains(nodes,"私はロボットではありません")){stop("追加認証が必要です");return;}
  boolean duplicateDialog=contains(nodes,"この商品は投稿済みです");
  if(DuplicatePolicy.shouldHandle(p,pkg,verified,duplicateDialog)){
   AccessibilityNodeInfo cancel=exact(nodes,"キャンセル");
   if(cancel==null){stop("投稿済み商品です。確認画面を閉じられないため停止しました");return;}
   if(!prefs.edit().putString("attempt:"+url,"already_posted").putString("phase","duplicate_closing").putString("status","投稿済みのためスキップします").putLong("deadline",System.currentTimeMillis()+15000).commit()){stop("投稿済み履歴の保存に失敗しました");return;}
   if(!cancel.performAction(AccessibilityNodeInfo.ACTION_CLICK))stop("投稿済み履歴を保存しました。画面を閉じられず停止しました");
   return;
  }
  if(p.equals("duplicate_closing")){
   if(!pkg.equals("com.rakuten.room")||duplicateDialog)return;
   advance();
   return;
  }
  if(p.equals("market")){if(!pkg.equals("jp.co.rakuten.android"))return;if(!verified){if(contains(nodes,"商品詳細")&&contains(nodes,keyword))verified=true;}AccessibilityNodeInfo share=exact(nodes,"ROOMに投稿");if(share!=null&&verified){phase("compose","ROOMへの移動を待っています");if(!share.performAction(AccessibilityNodeInfo.ACTION_CLICK))stop("ROOMボタンを操作できません");return;}if(System.currentTimeMillis()<lastScroll)return;if(scrolls>=12){stop("ROOMボタンが見つかりません。商品詳細画面を確認してください");return;}if(swipe(nodes,root)){scrolls++;lastScroll=System.currentTimeMillis()+Timing.range(prefs.getInt("op_min_ms",400),prefs.getInt("op_max_ms",1800));return;}return;}
  if(p.equals("compose")){if(!pkg.equals("com.rakuten.room")||!contains(nodes,keyword))return;List<AccessibilityNodeInfo> editors=new ArrayList<>();for(AccessibilityNodeInfo n:nodes)if(n.isVisibleToUser()&&n.isEditable()&&n.isEnabled())editors.add(n);AccessibilityNodeInfo submit=exact(nodes,"投稿する","投稿","コレ！");if(editors.size()!=1||submit==null)return;AccessibilityNodeInfo editor=editors.get(0);if(!comment.equals(label(editor))){Bundle args=new Bundle();args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,comment);if(!editor.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT,args))stop("紹介文を入力できません");return;}if(!publish){stop("プレビュー完了。紹介文を入力しました。公開していません");return;}if(prefs.contains("attempt:"+url)){stop("処理履歴があるため再投稿しません");return;}if(!prefs.edit().putString("attempt:"+url,"submission_attempted").putString("phase","result").putInt("session_attempts",prefs.getInt("session_attempts",0)+1).putLong("deadline",System.currentTimeMillis()+20000).commit()){stop("履歴保存失敗");return;}if(!submit.performAction(AccessibilityNodeInfo.ACTION_CLICK))stop("投稿操作を確認できません。結果をROOMで確認してください");}
 }
 @Override public void onAccessibilityEvent(AccessibilityEvent e){if(prefs==null||!prefs.getBoolean("running",false)||!"result".equals(prefs.getString("phase",""))||!"com.rakuten.room".contentEquals(e.getPackageName()==null?"":e.getPackageName()))return;if(!e.getText().toString().matches("(?s).*投稿(が)?(完了しました|しました).*"))return;try{int i=prefs.getInt("index",0);String url=new JSONArray(prefs.getString("items","[]")).getJSONObject(i).getString("url");if(!prefs.edit().putString("attempt:"+url,"success_message_observed").commit()){stop("結果履歴の保存失敗");return;}advance();}catch(Exception ex){stop("結果保存エラー");}}
 @Override public void onInterrupt(){if(prefs!=null)stop("ユーザー補助が中断されました");}
 @Override public void onDestroy(){searchWorker.shutdownNow();handler.removeCallbacksAndMessages(null);if(prefs!=null)stop("操作サービス終了");super.onDestroy();}
}
