package jp.roomhelper;
import android.app.*;
import android.content.*;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.widget.*;
import org.json.*;
import java.io.*;
public class MainActivity extends Activity {
 private android.content.SharedPreferences prefs; private TextView status;
 private final Handler handler=new Handler(Looper.getMainLooper());
 private final Runnable refresh=new Runnable(){public void run(){status.setText("ROOMキュー 0.7・楽天市場アプリ版\n"+prefs.getString("status","公式アプリでログインし、ユーザー補助を設定してください"));handler.postDelayed(this,1000);}};
 @Override public void onCreate(Bundle b){super.onCreate(b);prefs=getSharedPreferences("native_queue",0);LinearLayout root=new LinearLayout(this);root.setOrientation(1);root.setPadding(24,24,24,24);ScrollView scroll=new ScrollView(this);scroll.addView(root);setContentView(scroll);status=new TextView(this);root.addView(status);
  TextView help=new TextView(this);help.setText("楽天市場アプリ → ROOMに投稿 → 紹介文入力。\n初回ログイン・追加認証は本人が操作してください。処理中はロックせず対象アプリを前面にしてください。実機未検証です。");root.addView(help);
  button(root,"楽天市場アプリを開く",()->{stop();try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://item.rakuten.co.jp/f402052-iizuka/10000315/")).setPackage("jp.co.rakuten.android"));}catch(Exception e){say("公式楽天市場アプリが必要です");}});
  button(root,"ROOMアプリを開く",()->{stop();Intent i=getPackageManager().getLaunchIntentForPackage("com.rakuten.room");if(i!=null)startActivity(i);else say("公式ROOMアプリが必要です");});
  button(root,"ユーザー補助の設定",()->{stop();startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));});button(root,"キューを編集",this::edit);button(root,"無料の自動検索設定",this::editSearch);button(root,"次の商品までの待ち時間",this::editInterval);
  button(root,"プレビュー（公開しない）",()->begin(false));button(root,"自動投稿開始",()->new AlertDialog.Builder(this).setTitle("キューを公開").setMessage("公式ROOMで本人のアカウントと紹介文を確認してください。開始後は投稿ボタンを自動操作します。").setPositiveButton("開始",(d,w)->begin(true)).setNegativeButton("戻る",null).show());button(root,"停止",this::stop);TextView credit=new TextView(this);credit.setText("Supported by Rakuten Developers");credit.setTextColor(android.graphics.Color.BLUE);root.addView(credit);credit.setOnClickListener(v->{stop();startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://webservice.rakuten.co.jp/")));});
 }
 private void button(LinearLayout root,String label,Runnable action){Button b=new Button(this);b.setText(label);root.addView(b);b.setOnClickListener(v->action.run());}
 private void say(String s){prefs.edit().putString("status",s).apply();status.setText(s);}
 private void stop(){prefs.edit().putBoolean("running",false).putString("status","停止。クリック済みの投稿はROOMで確認してください").commit();}
 private String queue() throws Exception {if(prefs.contains("items"))return prefs.getString("items","");try(InputStream in=getAssets().open("items.json");ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] b=new byte[4096];int n;while((n=in.read(b))!=-1)out.write(b,0,n);return out.toString("UTF-8");}}
 private JSONArray validate(String text)throws Exception{JSONArray a=new JSONArray(text);if(a.length()<1||a.length()>50)throw new Exception("1〜50件で登録してください");java.util.HashSet<String> seen=new java.util.HashSet<>();for(int i=0;i<a.length();i++){JSONObject item=a.getJSONObject(i);Uri u=Uri.parse(item.getString("url"));if(!"https".equals(u.getScheme())||!"item.rakuten.co.jp".equals(u.getAuthority())||u.getPathSegments().size()!=2||u.getQuery()!=null||u.getFragment()!=null)throw new Exception("楽天の商品URLが必要です");if(!seen.add(item.getString("url"))||item.getString("keyword").trim().length()<3||item.getString("comment").trim().isEmpty())throw new Exception("URL重複・識別語・紹介文を確認してください");}return a;}
 private void edit(){stop();EditText e=new EditText(this);e.setMinLines(8);try{e.setText(queue());}catch(Exception ex){say("読み込み失敗");return;}new AlertDialog.Builder(this).setTitle("キューJSON").setView(e).setPositiveButton("保存",(d,w)->{try{String s=e.getText().toString();validate(s);prefs.edit().putString("items",s).apply();say("保存しました");}catch(Exception ex){say(ex.getMessage());}}).setNegativeButton("戻る",null).show();}
 private void editInterval(){stop();LinearLayout box=new LinearLayout(this);box.setOrientation(1);TextView help=new TextView(this);help.setText("秒数は小数3桁まで入力可能。商品間は0.1〜3600秒、操作間は0.1〜10秒。スクロール距離・時間も毎回変わります。");box.addView(help);
  EditText[] fields=new EditText[4];String[] labels={"次の商品まで：最短秒","次の商品まで：最長秒","操作間：最短秒","操作間：最長秒"};
  int[] values={prefs.getInt("min_wait_ms",prefs.getInt("min_wait",60)*1000),prefs.getInt("max_wait_ms",prefs.getInt("max_wait",180)*1000),prefs.getInt("op_min_ms",400),prefs.getInt("op_max_ms",1800)};
  for(int i=0;i<4;i++){TextView label=new TextView(this);label.setText(labels[i]);box.addView(label);fields[i]=new EditText(this);fields[i].setInputType(android.text.InputType.TYPE_CLASS_NUMBER|android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);fields[i].setText(new java.math.BigDecimal(values[i]).divide(new java.math.BigDecimal(1000)).toPlainString());box.addView(fields[i]);}
  new AlertDialog.Builder(this).setTitle("ランダム待ち時間").setView(box).setPositiveButton("保存",(d,w)->{try{
   int[] v=new int[4];for(int i=0;i<4;i++)v[i]=Timing.millis(fields[i].getText().toString());
   if(v[0]<100||v[1]<v[0]||v[1]>3600000||v[2]<100||v[3]<v[2]||v[3]>10000)throw new Exception();
   prefs.edit().putInt("min_wait_ms",v[0]).putInt("max_wait_ms",v[1]).putInt("op_min_ms",v[2]).putInt("op_max_ms",v[3]).apply();say("待ち時間を保存しました");
  }catch(Exception e){say("最短≦最長、小数3桁まで、指定範囲内で入力してください");}}).setNegativeButton("戻る",null).show();
 }
 private void editSearch(){stop();LinearLayout box=new LinearLayout(this);box.setPadding(24,12,24,12);box.setOrientation(1);ScrollView container=new ScrollView(this);container.addView(box);
  CheckBox enabled=new CheckBox(this);enabled.setText("固定検索・定型文で自動補充する");enabled.setChecked(prefs.getBoolean("auto_search",false));box.addView(enabled);
  TextView note=new TextView(this);note.setText("楽天APIは現在無料。楽天のアプリID・アクセスキーを取得し、この端末だけに入力してください。キーをChatGPTやGitHubに貼らないでください。商品は検索結果から選びます。取得した本文から効果やレビューを生成しません。");box.addView(note);
  EditText id=new EditText(this),key=new EditText(this),words=new EditText(this),template=new EditText(this),limit=new EditText(this);
  EditText[] inputs={id,key,words,template,limit};String[] labels={"楽天アプリID","アクセスキー（変更する場合だけ入力）","検索ワード（1行に1つ、最大10個）","固定文：{name} が商品名、{keyword} が検索ワード","1回の開始で投稿する上限件数"};
  for(int i=0;i<inputs.length;i++){TextView label=new TextView(this);label.setText(labels[i]);box.addView(label);box.addView(inputs[i]);}
  id.setText(prefs.getString("rakuten_app_id",""));key.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
  words.setMinLines(3);words.setText(prefs.getString("search_words","ふるさと納税\n日用品\nスイーツ"));template.setMinLines(3);template.setText(prefs.getString("search_template","{name}\n商品の詳細はこちらから！\n#{keyword} #楽天市場"));limit.setInputType(2);limit.setText(String.valueOf(prefs.getInt("session_limit",10)));
  new AlertDialog.Builder(this).setTitle("固定検索の設定").setView(container).setPositiveButton("保存",(d,w)->{try{
   String[] terms=words.getText().toString().trim().split("\\n");int count=Integer.parseInt(limit.getText().toString());
   if(terms.length<1||terms.length>10||count<1||count>100||template.getText().toString().trim().isEmpty())throw new Exception("検索ワード・定型文・件数（1〜100）を確認してください");
   for(String term:terms)if(term.trim().isEmpty()||term.trim().getBytes("UTF-8").length>128)throw new Exception("検索ワードは空欄不可、UTF-8で128バイトまで");
   String value=key.getText().toString().trim();if(!value.isEmpty())ApiCredentials.save(this,value);
   if(enabled.isChecked()&&(id.getText().toString().trim().isEmpty()||ApiCredentials.read(this).isEmpty()))throw new Exception("楽天のアプリIDとアクセスキーが必要です");
   prefs.edit().putBoolean("auto_search",enabled.isChecked()).putString("rakuten_app_id",id.getText().toString().trim()).putString("search_words",words.getText().toString().trim()).putString("search_template",template.getText().toString()).putInt("session_limit",count).apply();say("検索設定を保存しました");
  }catch(Exception e){say(e.getMessage());}}).setNegativeButton("戻る",null).setNeutralButton("楽天API登録",(d,w)->startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://webservice.rakuten.co.jp/")))).show();
 }
 private void begin(boolean publish){stop();android.view.accessibility.AccessibilityManager am=(android.view.accessibility.AccessibilityManager)getSystemService(ACCESSIBILITY_SERVICE);boolean enabled=false;for(android.accessibilityservice.AccessibilityServiceInfo s:am.getEnabledAccessibilityServiceList(android.accessibilityservice.AccessibilityServiceInfo.FEEDBACK_ALL_MASK)){if(s.getResolveInfo().serviceInfo.packageName.equals(getPackageName())&&s.getResolveInfo().serviceInfo.name.endsWith("NativePostService"))enabled=true;}if(!enabled){say("ユーザー補助でROOMキューの操作サービスを有効にしてください");return;}if(getPackageManager().getLaunchIntentForPackage("com.rakuten.room")==null){say("公式ROOMアプリが必要です");return;}try{boolean auto=prefs.getBoolean("auto_search",false);if(auto&&(prefs.getString("rakuten_app_id","").trim().isEmpty()||ApiCredentials.read(this).isEmpty()))throw new Exception("無料の自動検索設定で楽天APIを設定してください");String s=auto?"[]":queue();if(!auto)validate(s);prefs.edit().putString("items",s).putInt("index",0).putInt("session_success",0).putInt("session_attempts",0).putInt("search_cursor",0).putInt("search_calls",0).putString("session_id",java.util.UUID.randomUUID().toString()).putBoolean("publish",publish).putBoolean("running",true).putString("phase","launch").putLong("deadline",System.currentTimeMillis()+90000).putString("status","開始準備").commit();}catch(Exception e){say(e.getMessage());}}
 @Override protected void onResume(){super.onResume();handler.post(refresh);}
 @Override protected void onPause(){handler.removeCallbacks(refresh);super.onPause();}
}
