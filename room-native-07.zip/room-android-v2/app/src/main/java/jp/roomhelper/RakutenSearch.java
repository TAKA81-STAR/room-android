package jp.roomhelper;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import org.json.*;
import java.io.*;
import java.net.*;

final class RakutenSearch {
    static JSONArray fetch(Context context,String keyword,int page) throws Exception {
        SharedPreferences prefs=context.getSharedPreferences("native_queue",0);
        String appId=prefs.getString("rakuten_app_id","").trim(), accessKey=ApiCredentials.read(context);
        if(appId.isEmpty()||accessKey.isEmpty())throw new Exception("楽天APIのアプリIDとアクセスキーを設定してください");
        Uri endpoint=Uri.parse("https://openapi.rakuten.co.jp/ichibams/api/IchibaItem/Search/20260701").buildUpon()
          .appendQueryParameter("applicationId",appId).appendQueryParameter("keyword",keyword)
          .appendQueryParameter("page",String.valueOf(page)).appendQueryParameter("hits","30")
          .appendQueryParameter("availability","1").appendQueryParameter("format","json")
          .appendQueryParameter("formatVersion","2").appendQueryParameter("elements","itemName,itemUrl,availability").build();
        HttpURLConnection connection=(HttpURLConnection)new URL(endpoint.toString()).openConnection();
        connection.setConnectTimeout(10000);connection.setReadTimeout(15000);connection.setInstanceFollowRedirects(false);
        // Keep the access key out of URLs, logs, APK assets and GitHub.
        connection.setRequestProperty("accessKey",accessKey);
        try {
            int code=connection.getResponseCode();
            if(code!=200)throw new Exception(code==429?"楽天APIのアクセス上限です。時間を置いて再開してください":"楽天APIに接続できません（HTTP "+code+"）。登録内容とAPIの利用条件を確認してください");
            ByteArrayOutputStream buffer=new ByteArrayOutputStream();
            try(InputStream in=connection.getInputStream()){byte[] chunk=new byte[4096];int n;while((n=in.read(chunk))!=-1){buffer.write(chunk,0,n);if(buffer.size()>2097152)throw new Exception("API応答が大きすぎます");}}
            JSONObject body=new JSONObject(buffer.toString("UTF-8"));
            JSONArray result=body.optJSONArray("items");if(result==null)result=body.optJSONArray("Items");
            if(result==null)throw new Exception("楽天APIの応答形式を確認できません");
            return result;
        } finally { connection.disconnect(); }
    }
}
