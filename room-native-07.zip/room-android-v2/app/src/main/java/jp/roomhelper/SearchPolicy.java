package jp.roomhelper;

final class SearchPolicy {
    static String canonicalUrl(String source) {
        try {
            java.net.URI uri = new java.net.URI(source);
            String path = uri.getPath();
            if (!"item.rakuten.co.jp".equalsIgnoreCase(uri.getHost()) || uri.getUserInfo()!=null || uri.getPort()!=-1 ||
                !("https".equals(uri.getScheme()) || "http".equals(uri.getScheme())) || path==null || !path.matches("/[^/]+/[^/]+/?")) return null;
            return new java.net.URI("https", "item.rakuten.co.jp", path.endsWith("/")?path:path+"/", null).toASCIIString();
        } catch (Exception e) { return null; }
    }
    static String render(String template, String name, String keyword) {
        return template.replace("{name}",name).replace("{keyword}",keyword.replaceAll("\\s+", ""));
    }
    static String identifier(String name) {
        // Preserve a concrete part of the actual product title, rather than using a category tag.
        String clean=name.trim().replaceAll("^[【\\[].*?[】\\]]\\s*", "");
        if(clean.length()<3) clean=name.trim();
        return clean.substring(0,Math.min(32,clean.length()));
    }
    static boolean limitReached(int successful, int limit) { return successful>=limit; }
}
