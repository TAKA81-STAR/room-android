package jp.roomhelper;

/** Only handle an existing-post dialog after opening ROOM from a verified product. */
final class DuplicatePolicy {
    static boolean shouldHandle(String phase, String packageName, boolean verified, boolean dialog) {
        return verified && dialog && "compose".equals(phase) && "com.rakuten.room".equals(packageName);
    }
}
