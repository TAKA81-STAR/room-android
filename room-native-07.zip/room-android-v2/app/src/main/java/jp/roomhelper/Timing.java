package jp.roomhelper;

final class Timing {
    static int millis(String seconds) {
        return new java.math.BigDecimal(seconds.trim()).multiply(new java.math.BigDecimal(1000)).intValueExact();
    }
    static int range(int min, int max) {
        if (min < 1 || max < min || max == Integer.MAX_VALUE) throw new IllegalArgumentException("Invalid timing range");
        return java.util.concurrent.ThreadLocalRandom.current().nextInt(min, max + 1);
    }
}
