package jp.roomhelper;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.WindowManager;
import android.webkit.*;
import android.widget.*;
import org.json.*;
import java.io.*;

public class MainActivity extends Activity {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private WebView browser;
    private TextView status;
    private EditText queueEditor;
    private SharedPreferences prefs;
    private JSONArray items;
    private JSONObject current;
    private String script, phase;
    private int index, generation;
    private long deadline;
    private boolean running, publish, loaded;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs=getSharedPreferences("queue",MODE_PRIVATE);
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(12,12,12,12);
        setContentView(root);
        status=new TextView(this); status.setText("試作・未実機検証。初回ログイン → キュー確認 → 開始"); root.addView(status);
        LinearLayout controls=new LinearLayout(this); root.addView(controls);
        button(controls,"ログイン", () -> { stop("手動ログイン中"); browser.loadUrl("https://room.rakuten.co.jp/"); });
        button(controls,"キュー",this::editQueue);
        button(controls,"停止", () -> stop("停止しました。クリック済みの投稿はROOMで確認してください"));
        LinearLayout actions=new LinearLayout(this); root.addView(actions);
        button(actions,"プレビュー", () -> begin(false));
        button(actions,"自動投稿開始", () -> new AlertDialog.Builder(this).setTitle("キューを公開")
            .setMessage("表示中のログインアカウントで、キューの商品を順番に公開します。開始後は投稿直前の確認なしで進みます。内容とアカウントを確認してください。")
            .setPositiveButton("開始",(d,w)->begin(true)).setNegativeButton("戻る",null).show());
        browser=new WebView(this); root.addView(browser,new LinearLayout.LayoutParams(-1,0,1));
        browser.getSettings().setJavaScriptEnabled(true);
        browser.getSettings().setDomStorageEnabled(true);
        browser.getSettings().setAllowFileAccess(false);
        browser.getSettings().setAllowContentAccess(false);
        browser.getSettings().setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        CookieManager.getInstance().setAcceptCookie(true);
        browser.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                if (!request.isForMainFrame()) return false;
                if (!allowed(request.getUrl())) { stop("楽天以外への移動を停止しました"); return true; }
                if (running && !operationHost(request.getUrl())) stop("追加のログイン・認証が必要です。手動で確認してください");
                return false;
            }
            @Override public void onPageStarted(WebView v,String url,Bitmap icon) { loaded=false; }
            @Override public void onPageFinished(WebView v,String url) { loaded=true; CookieManager.getInstance().flush(); }
            @Override public void onReceivedSslError(WebView v,SslErrorHandler h,SslError e) { h.cancel(); stop("証明書エラーで停止しました"); }
            @Override public void onReceivedError(WebView v,WebResourceRequest r,WebResourceError e) { if(r.isForMainFrame()) stop("通信エラーで停止しました"); }
        });
        try { script=asset("automation.js"); } catch(Exception e) { stop("スクリプトを読み込めません"); }
        browser.loadUrl("https://room.rakuten.co.jp/");
    }

    private void button(LinearLayout parent,String label,Runnable action) {
        Button button=new Button(this); button.setText(label); button.setTextSize(12); parent.addView(button,new LinearLayout.LayoutParams(0,-2,1));
        button.setOnClickListener(v->action.run());
    }
    private String asset(String name) throws IOException {
        try(InputStream stream=getAssets().open(name); ByteArrayOutputStream out=new ByteArrayOutputStream()) {
            byte[] buffer=new byte[4096]; int n; while((n=stream.read(buffer))!=-1) out.write(buffer,0,n); return out.toString("UTF-8");
        }
    }
    private boolean allowed(Uri uri) {
        String host=uri.getHost(); return "https".equals(uri.getScheme()) && host!=null &&
            (host.equals("rakuten.co.jp") || host.endsWith(".rakuten.co.jp") || host.equals("rakuten.com") || host.endsWith(".rakuten.com"));
    }
    private boolean operationHost(Uri uri) { return "room.rakuten.co.jp".equals(uri.getHost()) || "item.rakuten.co.jp".equals(uri.getHost()); }
    private String queue() throws IOException { return prefs.getString("items",asset("items.json")); }
    private void editQueue() {
        stop("キュー編集中"); queueEditor=new EditText(this); queueEditor.setMinLines(8);
        try { queueEditor.setText(queue()); } catch(Exception e) { status.setText("キュー読み込み失敗"); return; }
        new AlertDialog.Builder(this).setTitle("URL・識別語・紹介文のJSON").setView(queueEditor)
            .setPositiveButton("保存",(d,w)-> {
                try { String value=queueEditor.getText().toString(); validate(value); prefs.edit().putString("items",value).apply(); status.setText("キューを保存しました"); }
                catch(Exception e) { status.setText("保存失敗: "+e.getMessage()); }
            }).setNegativeButton("戻る",null).show();
    }
    private JSONArray validate(String source) throws Exception {
        JSONArray list=new JSONArray(source); if(list.length()<1 || list.length()>50) throw new Exception("件数は1〜50件");
        java.util.HashSet<String> seen=new java.util.HashSet<>();
        for(int i=0;i<list.length();i++) {
            JSONObject item=list.getJSONObject(i); String url=item.getString("url"); Uri uri=Uri.parse(url);
            if(!"https".equals(uri.getScheme()) || !"item.rakuten.co.jp".equals(uri.getAuthority()) || uri.getQuery()!=null || uri.getFragment()!=null || uri.getPathSegments().size()!=2) throw new Exception("楽天商品URLが必要です");
            if(!seen.add(url)) throw new Exception("URL重複");
            if(item.getString("keyword").trim().length()<3 || item.getString("comment").trim().isEmpty()) throw new Exception("識別語は3文字以上、紹介文は必須");
        }
        return list;
    }
    private void begin(boolean doPublish) {
        stop("開始準備");
        try { items=validate(queue()); } catch(Exception e) { status.setText("キューエラー: "+e.getMessage()); return; }
        publish=doPublish; running=true; index=-1; generation++; getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); next();
    }
    private void next() {
        if(!running) return;
        try {
            do { index++; } while(index<items.length() && publish && prefs.contains("attempt:"+items.getJSONObject(index).getString("url")));
            if(index>=items.length()) { stop("キューの処理が終了しました。結果はROOMで確認してください"); return; }
            current=items.getJSONObject(index); phase="product"; deadline=System.currentTimeMillis()+45000;
            status.setText((index+1)+"/"+items.length()+" 商品画面を開いています"); browser.loadUrl(current.getString("url")); schedule();
        } catch(Exception e) { stop("キュー処理エラー"); }
    }
    private void schedule() { int expected=generation; handler.postDelayed(()->{if(running && generation==expected) tick();},1000); }
    private void tick() {
        if(!running) return;
        if(System.currentTimeMillis()>deadline) { stop("画面確認がタイムアウトしました。投稿結果はROOMで確認してください"); return; }
        if(!loaded) { schedule(); return; }
        try {
            JSONObject input=new JSONObject(current.toString()); input.put("phase",phase);
            int expected=generation;
            // Quote input into a string first: product comments cannot become executable JavaScript.
            String value="JSON.parse("+JSONObject.quote(input.toString())+")";
            String code=script.replace("__INPUT__",value);
            browser.evaluateJavascript(code,result->{
                if(!running || generation!=expected) return;
                try { react(new JSONObject(result)); } catch(Exception e) { stop("画面応答を確認できず停止しました"); }
            });
        } catch(Exception e) { stop("操作エラーで停止しました"); }
    }
    private void react(JSONObject result) throws Exception {
        String s=result.optString("status");
        if(s.equals("wait") || s.equals("filled")) { schedule(); return; }
        if(s.equals("room_link")) {
            String url=result.getString("url"); Uri uri=Uri.parse(url);
            if(!"https".equals(uri.getScheme()) || !"room.rakuten.co.jp".equals(uri.getAuthority())) { stop("共有リンク不一致"); return; }
            phase="fill"; deadline=System.currentTimeMillis()+45000; browser.loadUrl(url); status.setText("対象商品と紹介文を確認中"); schedule(); return;
        }
        if(s.equals("ready")) {
            if(!publish) { stop("プレビュー完了。公開ボタンは押していません。キューのこの商品を表示しています"); return; }
            String key="attempt:"+current.getString("url");
            if(prefs.contains(key)) { stop("処理履歴がある商品です"); return; }
            if(!prefs.edit().putString(key,"submission_attempted").commit()) { stop("履歴保存に失敗したため投稿しません"); return; }
            phase="submit"; status.setText("投稿ボタンを1回操作します"); schedule(); return;
        }
        if(s.equals("clicked")) { phase="result"; deadline=System.currentTimeMillis()+20000; status.setText("投稿結果を確認中"); schedule(); return; }
        if(s.equals("success")) { prefs.edit().putString("attempt:"+current.getString("url"),"success_message_observed").commit(); next(); return; }
        stop("停止: "+s+"。商品・画面またはログイン状態を確認してください");
    }
    private void stop(String message) { running=false; generation++; handler.removeCallbacksAndMessages(null); if(status!=null)status.setText(message); getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); }
    @Override protected void onPause() { super.onPause(); stop("バックグラウンド移行で停止。公開結果はROOMで確認してください"); CookieManager.getInstance().flush(); }
    @Override protected void onDestroy() { stop("終了"); if(browser!=null)browser.destroy(); super.onDestroy(); }
}
