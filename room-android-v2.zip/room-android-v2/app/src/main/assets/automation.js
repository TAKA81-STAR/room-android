(function () {
  'use strict';
  // evaluateJavascript supplies a per-call input. No JavaScript bridge is exposed.
  const input = __INPUT__;
  const visible = el => !!(el.getClientRects().length && getComputedStyle(el).visibility !== 'hidden' && getComputedStyle(el).display !== 'none');
  const text = el => (el.innerText || el.textContent || '').trim();
  const body = document.body;
  if (!body) return {status: 'wait'};
  if (document.querySelector('input[type="password"]') || /captcha|認証コード|私はロボットではありません/i.test(body.innerText)) return {status: 'authentication'};
  if (input.phase === 'product') {
    if (location.origin !== 'https://item.rakuten.co.jp' || location.pathname.replace(/\/$/, '') !== new URL(input.url).pathname.replace(/\/$/, '')) return {status: 'wrong_product'};
    if (!body.innerText.includes(input.keyword)) return {status: 'wait'};
    const links = [...document.querySelectorAll('a[href]')].filter(el => {
      if (!visible(el)) return false;
      try { return new URL(el.href).origin === 'https://room.rakuten.co.jp'; } catch (_) { return false; }
    });
    if (links.length !== 1) return {status: 'share_missing', count: links.length};
    return {status: 'room_link', url: links[0].href};
  }
  if (location.origin !== 'https://room.rakuten.co.jp') return {status: 'authentication'};
  if (input.phase === 'result') {
    const messages = [...document.querySelectorAll('[role="alert"], [role="status"], .toast, .notification')].filter(visible);
    return {status: messages.some(el => /投稿(が)?(完了しました|しました)/.test(text(el))) ? 'success' : 'wait'};
  }
  // Match the exact item URL on the composer, not merely a keyword elsewhere on the page.
  const matchedProduct = [...document.querySelectorAll('a[href]')].some(el => {
    try {
      const u = new URL(el.href), wanted = new URL(input.url);
      return u.origin === wanted.origin && u.pathname.replace(/\/$/, '') === wanted.pathname.replace(/\/$/, '');
    } catch (_) { return false; }
  });
  if (!matchedProduct || !body.innerText.includes(input.keyword)) return {status: 'product_unverified'};
  const editors = [...document.querySelectorAll('textarea')].filter(el => visible(el) && !el.disabled && !el.readOnly);
  const buttons = [...document.querySelectorAll('button, input[type="submit"], [role="button"]')].filter(el => visible(el) && !el.disabled && el.getAttribute('aria-disabled') !== 'true' && /^(投稿する|投稿)$/.test(el.value || text(el)));
  if (editors.length !== 1 || buttons.length !== 1) return {status: 'composer_missing'};
  const editor = editors[0];
  if (input.phase === 'fill') {
    if (editor.value !== input.comment) {
      const setter = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value').set;
      setter.call(editor, input.comment);
      editor.dispatchEvent(new Event('input', {bubbles: true}));
      editor.dispatchEvent(new Event('change', {bubbles: true}));
      return {status: 'filled'};
    }
    return {status: 'ready'};
  }
  if (input.phase === 'submit') {
    if (editor.value !== input.comment) return {status: 'text_mismatch'};
    buttons[0].click();
    return {status: 'clicked'};
  }
  return {status: 'unknown_phase'};
})();
