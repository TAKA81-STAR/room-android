package jp.roomhelper;
import android.accessibilityservice.AccessibilityService;
import android.content.*;
import android.net.Uri;
import android.os.*;
import android.view.accessibility.*;
import org.json.*;
import java.util.*;
public class NativePostService extends AccessibilityService {
 private SharedPreferences prefs;private int scrolls;private boolean verified;private long lastScroll;
 private final Handler handler=new Handler(Looper.getMainLooper());
 private final Runnable loop=new Runnable(){public void run(){try{tick();}catch(Exception e){stop("画面操作エラー: "+e.getClass().getSimpleName());}handler.postDelayed(this,1000+java.util.concurrent.ThreadLocalRandom.current().nextInt(1501));}};
 @Override protected void onServiceConnected(){prefs=getSharedPreferences("native_queue",0);handler.post(loop);}
 private void stop(String s){prefs.edit().putBoolean("running",false).putString("status",s).commit();}
 private void phase(String p,String s){prefs.edit().putString("phase",p).putString("status",s).putLong("deadline",System.currentTimeMillis()+90000).commit();}
 private String label(AccessibilityNodeInfo n){return n.getText()!=null?n.getText().toString().trim():n.getContentDescription()!=null?n.getContentDescription().toString().trim():"";}
 private void collect(AccessibilityNodeInfo n,List<AccessibilityNodeInfo> out){if(n==null||out.size()>1500)return;out.add(n);for(int i=0;i<n.getChildCount();i++)collect(n.getChild(i),out);}
 private boolean contains(List<AccessibilityNodeInfo> nodes,String token){for(AccessibilityNodeInfo n:nodes)if(n.isVisibleToUser()&&!n.isEditable()&&label(n).contains(token))return true;return false;}
 private AccessibilityNodeInfo exact(List<AccessibilityNodeInfo> nodes,String... labels){Set<AccessibilityNodeInfo> found=new HashSet<>();for(AccessibilityNodeInfo n:nodes)if(n.isVisibleToUser())for(String s:labels)if(s.equals(label(n))){AccessibilityNodeInfo c=n;for(int i=0;c!=null&&i<5;i++,c=c.getParent())if(c.isClickable()&&c.isEnabled()){found.add(c);break;}}return found.size()==1?found.iterator().next():null;}
 private void tick()throws Exception{
  if(!prefs.getBoolean("running",false))return;android.os.PowerManager power=(android.os.PowerManager)getSystemService(POWER_SERVICE);android.app.KeyguardManager keyguard=(android.app.KeyguardManager)getSystemService(KEYGUARD_SERVICE);if(!power.isInteractive()||keyguard.isKeyguardLocked()){stop("画面ロックで停止しました");return;}if(System.currentTimeMillis()>prefs.getLong("deadline",0)){stop("画面確認がタイムアウト。ROOMで結果を確認してください");return;}
  JSONArray queue=new JSONArray(prefs.getString("items","[]"));int index=prefs.getInt("index",0);boolean publish=prefs.getBoolean("publish",false);if(index>=queue.length()){stop("キュー処理終了。ROOMで結果を確認してください");return;}
  JSONObject item=queue.getJSONObject(index);String url=item.getString("url"),keyword=item.getString("keyword"),comment=item.getString("comment"),p=prefs.getString("phase","launch");
  if(p.equals("launch")){if((publish&&prefs.contains("attempt:"+url))||"already_posted".equals(prefs.getString("attempt:"+url,""))){prefs.edit().putInt("index",index+1).commit();return;}Uri target=Uri.parse(url);if(!"https".equals(target.getScheme())||!"item.rakuten.co.jp".equals(target.getAuthority())||target.getPathSegments().size()!=2){stop("商品URL不一致");return;}scrolls=0;verified=false;lastScroll=0;phase("market",(index+1)+"/"+queue.length()+" 楽天市場アプリで商品を確認中");try{startActivity(new Intent(Intent.ACTION_VIEW,target).setPackage("jp.co.rakuten.android").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));}catch(ActivityNotFoundException e){stop("楽天市場アプリが見つかりません");}return;}
  AccessibilityNodeInfo root=getRootInActiveWindow();if(root==null)return;String pkg=root.getPackageName()==null?"":root.getPackageName().toString();if(!pkg.equals("jp.co.rakuten.android")&&!pkg.equals("com.rakuten.room"))return;
  List<AccessibilityNodeInfo> nodes=new ArrayList<>();collect(root,nodes);for(AccessibilityNodeInfo n:nodes)if(n.isPassword()){stop("ログインを本人が行ってください");return;}if(contains(nodes,"認証コード")||contains(nodes,"私はロボットではありません")){stop("追加認証が必要です");return;}
  boolean duplicateDialog=contains(nodes,"この商品は投稿済みです");
  if(DuplicatePolicy.shouldHandle(p,pkg,verified,duplicateDialog)){
   AccessibilityNodeInfo cancel=exact(nodes,"キャンセル");
   if(cancel==null){stop("投稿済み商品です。確認画面を閉じられないため停止しました");return;}
   if(!prefs.edit().putString("attempt:"+url,"already_posted").putString("phase","duplicate_closing").putString("status","投稿済みのためスキップします").putLong("deadline",System.currentTimeMillis()+15000).commit()){stop("投稿済み履歴の保存に失敗しました");return;}
   if(!cancel.performAction(AccessibilityNodeInfo.ACTION_CLICK))stop("投稿済み履歴を保存しました。画面を閉じられず停止しました");
   return;
  }
  if(p.equals("duplicate_closing")){
   if(!pkg.equals("com.rakuten.room")||duplicateDialog)return;
   prefs.edit().putInt("index",index+1).putString("phase","launch").putLong("deadline",System.currentTimeMillis()+90000).commit();
   return;
  }
  if(p.equals("market")){if(!pkg.equals("jp.co.rakuten.android"))return;if(!verified){if(contains(nodes,"商品詳細")&&contains(nodes,keyword))verified=true;}AccessibilityNodeInfo share=exact(nodes,"ROOMに投稿");if(share!=null&&verified){phase("compose","ROOMへの移動を待っています");if(!share.performAction(AccessibilityNodeInfo.ACTION_CLICK))stop("ROOMボタンを操作できません");return;}if(System.currentTimeMillis()-lastScroll<3000)return;if(scrolls>=12){stop("ROOMボタンが見つかりません。商品詳細画面を確認してください");return;}for(AccessibilityNodeInfo n:nodes)if(n.isVisibleToUser()&&n.isScrollable()&&n.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)){scrolls++;lastScroll=System.currentTimeMillis();return;}return;}
  if(p.equals("compose")){if(!pkg.equals("com.rakuten.room")||!contains(nodes,keyword))return;List<AccessibilityNodeInfo> editors=new ArrayList<>();for(AccessibilityNodeInfo n:nodes)if(n.isVisibleToUser()&&n.isEditable()&&n.isEnabled())editors.add(n);AccessibilityNodeInfo submit=exact(nodes,"投稿する","投稿","コレ！");if(editors.size()!=1||submit==null)return;AccessibilityNodeInfo editor=editors.get(0);if(!comment.equals(label(editor))){Bundle args=new Bundle();args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,comment);if(!editor.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT,args))stop("紹介文を入力できません");return;}if(!publish){stop("プレビュー完了。紹介文を入力しました。公開していません");return;}if(prefs.contains("attempt:"+url)){stop("処理履歴があるため再投稿しません");return;}if(!prefs.edit().putString("attempt:"+url,"submission_attempted").putString("phase","result").putLong("deadline",System.currentTimeMillis()+20000).commit()){stop("履歴保存失敗");return;}if(!submit.performAction(AccessibilityNodeInfo.ACTION_CLICK))stop("投稿操作を確認できません。結果をROOMで確認してください");}
 }
 @Override public void onAccessibilityEvent(AccessibilityEvent e){if(prefs==null||!prefs.getBoolean("running",false)||!"result".equals(prefs.getString("phase",""))||!"com.rakuten.room".contentEquals(e.getPackageName()==null?"":e.getPackageName()))return;if(!e.getText().toString().matches("(?s).*投稿(が)?(完了しました|しました).*"))return;try{int i=prefs.getInt("index",0);String url=new JSONArray(prefs.getString("items","[]")).getJSONObject(i).getString("url");prefs.edit().putString("attempt:"+url,"success_message_observed").putInt("index",i+1).putString("phase","launch").putLong("deadline",System.currentTimeMillis()+90000).commit();}catch(Exception ex){stop("結果保存エラー");}}
 @Override public void onInterrupt(){if(prefs!=null)stop("ユーザー補助が中断されました");}
 @Override public void onDestroy(){handler.removeCallbacksAndMessages(null);if(prefs!=null)stop("操作サービス終了");super.onDestroy();}
}
