package jp.roomhelper;

final class NativeCandidate {
    static boolean looksLikeTitle(String name,String word) {
        if(name==null||name.length()<12||name.length()>400||!name.contains(word))return false;
        return !name.contains("検索結果") && !name.contains("検索する") && !name.contains("キーワードから探す") &&
            !name.contains("寄付を申し込む") && !name.contains("購入手続き") && !name.contains("楽天ポイントの獲得") && !name.contains("レビューを書く");
    }
    static String identifier(String name) { return name.substring(0,Math.min(32,name.length())); }
    static boolean isPrice(String text) {
        return text!=null && text.matches("(?s).*(?:[¥￥]\\s*[0-9,]+|[0-9,]+\\s*円).*");
    }
    static boolean sameRow(int titleLeft,int titleTop,int titleBottom,int priceLeft,int priceTop,int allowance) {
        return priceLeft>=titleLeft-32 && priceTop>=titleTop-16 && priceTop<=titleBottom+allowance;
    }
    static String comment(String template,String word) {
        String result=template.contains("{keyword}")?template.replace("{keyword}",word):word+"はこちら！\n"+template;
        if(result.length()>500)throw new IllegalArgumentException("検索ワード付きの紹介文が500文字を超えています");
        return result;
    }
    static String id(String name) {
        try {
            byte[] bytes=java.security.MessageDigest.getInstance("SHA-256").digest(name.trim().replaceAll("\\s+"," ").getBytes("UTF-8"));
            StringBuilder out=new StringBuilder("native:");for(byte b:bytes)out.append(String.format(java.util.Locale.ROOT,"%02x",b&255));return out.toString();
        }catch(Exception e){throw new IllegalStateException(e);}
    }
}
