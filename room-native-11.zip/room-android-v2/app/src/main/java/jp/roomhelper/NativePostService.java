package jp.roomhelper;
import android.accessibilityservice.AccessibilityService;
import android.content.*;
import android.net.Uri;
import android.os.*;
import android.view.accessibility.*;
import org.json.*;
import java.util.*;
public class NativePostService extends AccessibilityService {
 private SharedPreferences prefs;private int scrolls;private boolean verified,gesturePending;private long lastScroll;
 private PowerManager.WakeLock screenLock;private long lockRenewedAt;private String searchWord="";private boolean searchSubmitted;
 private final Handler handler=new Handler(Looper.getMainLooper());
 private final Runnable loop=new Runnable(){public void run(){try{tick();}catch(Exception e){stop("操作停止："+e.getClass().getSimpleName());}handler.postDelayed(this,Timing.range(prefs==null?400:prefs.getInt("op_min_ms",400),prefs==null?1800:prefs.getInt("op_max_ms",1800)));}};
 @Override protected void onServiceConnected(){prefs=getSharedPreferences("native_queue",0);stop("準備完了。開始を押すまで停止しています");handler.post(loop);}
 private void stop(String s){String phase=prefs.getString("phase","未開始");String previous=prefs.getString("status","");prefs.edit().putBoolean("running",false).putString("status",s).putString("diagnostic","停止理由："+s+"\n処理段階："+phase+"\n直前："+previous).commit();releaseScreen();}
 private void releaseScreen(){if(screenLock!=null&&screenLock.isHeld())screenLock.release();}
 @SuppressWarnings("deprecation") private void keepScreen(PowerManager power){
  if(screenLock==null){screenLock=power.newWakeLock(PowerManager.SCREEN_BRIGHT_WAKE_LOCK,"roomhelper:active-session");screenLock.setReferenceCounted(false);}
  long now=SystemClock.elapsedRealtime();
  if(!screenLock.isHeld()||now-lockRenewedAt>240000){releaseScreen();screenLock.acquire(600000);lockRenewedAt=now;}
 }

 private void phase(String p,String s){prefs.edit().putString("phase",p).putString("status",s).putLong("deadline",System.currentTimeMillis()+90000).commit();}
 private void advance(){
  int low=prefs.getInt("min_wait_ms",60000),high=prefs.getInt("max_wait_ms",180000);
  if(low<100||high<low||high>3600000){stop("待ち時間を設定し直してください");return;}
  long until=System.currentTimeMillis()+Timing.range(low,high);
  prefs.edit().putString("phase","interval").putLong("wait_until",until).putLong("deadline",until+90000).putString("status","次の商品まで待っています").commit();
 }
 private AccessibilityNodeInfo ancestorClick(AccessibilityNodeInfo node){for(int i=0;node!=null&&i<5;i++,node=node.getParent())if(node.isClickable()&&node.isEnabled())return node;return null;}
 private boolean priceIn(AccessibilityNodeInfo node,int depth){if(node==null||depth>4)return false;if(label(node).matches("(?s).*(?:[¥￥][\\d,]+|[\\d,]+円).*"))return true;for(int i=0;i<node.getChildCount();i++)if(priceIn(node.getChild(i),depth+1))return true;return false;}
 private boolean nearbyPrice(AccessibilityNodeInfo title,List<AccessibilityNodeInfo> nodes,AccessibilityNodeInfo root){
  android.graphics.Rect t=new android.graphics.Rect(),r=new android.graphics.Rect();title.getBoundsInScreen(t);root.getBoundsInScreen(r);
  int allowance=Math.max(80,Math.min(240,r.height()/8));
  for(AccessibilityNodeInfo n:nodes)if(n.isVisibleToUser()&&NativeCandidate.isPrice(label(n))){android.graphics.Rect b=new android.graphics.Rect();n.getBoundsInScreen(b);if(NativeCandidate.sameRow(t.left,t.top,t.bottom,b.left,b.top,allowance))return true;}
  return false;
 }
 private boolean openTitle(AccessibilityNodeInfo title,AccessibilityNodeInfo root){
  AccessibilityNodeInfo card=ancestorClick(title);if(card!=null&&card.performAction(AccessibilityNodeInfo.ACTION_CLICK))return true;
  // Tap the confirmed product-name rectangle only, never a guessed location or a purchase control.
  android.graphics.Rect b=new android.graphics.Rect(),r=new android.graphics.Rect();title.getBoundsInScreen(b);root.getBoundsInScreen(r);
  if(!b.intersect(r)||b.width()<80||b.height()<20||b.height()>r.height()/3)return false;
  android.graphics.Path path=new android.graphics.Path();path.moveTo(b.exactCenterX(),b.exactCenterY());
  gesturePending=true;
  boolean accepted=dispatchGesture(new android.accessibilityservice.GestureDescription.Builder().addStroke(new android.accessibilityservice.GestureDescription.StrokeDescription(path,0,Timing.range(60,140))).build(),new GestureResultCallback(){
   @Override public void onCompleted(android.accessibilityservice.GestureDescription g){gesturePending=false;}
   @Override public void onCancelled(android.accessibilityservice.GestureDescription g){gesturePending=false;if(prefs.getBoolean("running",false))stop("商品名の選択が中断されました");}
  },handler);
  if(!accepted)gesturePending=false;return accepted;
 }
 private void searchLaunch() throws Exception {
  String[] words=prefs.getString("native_words","ふるさと納税\n日用品\nスイーツ").split("\\n");
  int cursor=prefs.getInt("native_cursor",0);if(cursor>=words.length*20){stop("検索した範囲の候補を探し終えました。検索ワードを変えてください");return;}
  searchWord=words[cursor%words.length].trim();int page=1+cursor/words.length;
  scrolls=0;lastScroll=0;verified=false;searchSubmitted=false;
  String url="https://search.rakuten.co.jp/search/mall/"+Uri.encode(searchWord)+"/?p="+page;
  phase("search_results","楽天市場アプリで検索中："+searchWord+"（"+page+"ページ）");
  try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)).setPackage("jp.co.rakuten.android").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));}
  catch(ActivityNotFoundException e){Intent launch=getPackageManager().getLaunchIntentForPackage("jp.co.rakuten.android");if(launch==null){stop("公式楽天市場アプリが必要です");return;}startActivity(launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));}
 }
 private void choose(List<AccessibilityNodeInfo> nodes,AccessibilityNodeInfo root) throws Exception {
  List<AccessibilityNodeInfo> titles=new ArrayList<>();Set<String> names=new HashSet<>();int titleCount=0,priceCount=0;for(AccessibilityNodeInfo n:nodes)if(n.isVisibleToUser()){if(NativeCandidate.looksLikeTitle(label(n),searchWord))titleCount++;if(NativeCandidate.isPrice(label(n)))priceCount++;}prefs.edit().putString("diagnostic","検索結果：商品名候補="+titleCount+"、価格表示="+priceCount+"、検索語="+searchWord).apply();
  for(AccessibilityNodeInfo n:nodes){
   String name=label(n);if(!n.isVisibleToUser()||n.isEditable()||!NativeCandidate.looksLikeTitle(name,searchWord)||!names.add(name))continue;
   AccessibilityNodeInfo card=ancestorClick(n);if(!(card!=null&&priceIn(card,0))&&!nearbyPrice(n,nodes,root))continue;
   String id=NativeCandidate.id(name);if(prefs.contains("attempt:"+id))continue;
   titles.add(n);
  }
  if(!titles.isEmpty()){
   Collections.shuffle(titles);AccessibilityNodeInfo title=titles.get(0),card=ancestorClick(title);
   String name=label(title),id=NativeCandidate.id(name);String fixed=NativeCandidate.comment(prefs.getString("native_comment","{keyword}はこちら！\n#楽天市場 #お買い物"),searchWord);
   JSONObject item=new JSONObject().put("url",id).put("keyword",NativeCandidate.identifier(name)).put("comment",fixed);
   prefs.edit().putString("current_native",item.toString()).commit();verified=false;scrolls=0;lastScroll=0;phase("market","選んだ商品の詳細を確認中");
   if(!openTitle(title,root))stop("検索結果の商品名を操作できません。診断画面を確認してください");return;
  }
  // If the app opened its home/search entry rather than results, use its own search field.
  if(!searchSubmitted){List<AccessibilityNodeInfo> fields=new ArrayList<>();for(AccessibilityNodeInfo n:nodes)if(n.isVisibleToUser()&&n.isEditable()&&n.isEnabled()&&!n.isPassword())fields.add(n);
   if(fields.size()==1){AccessibilityNodeInfo field=fields.get(0);Bundle b=new Bundle();b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,searchWord);
    if(field.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT,b)){searchSubmitted=true;AccessibilityNodeInfo search=exact(nodes,"検索","検索する");if(search!=null)search.performAction(AccessibilityNodeInfo.ACTION_CLICK);else if(Build.VERSION.SDK_INT>=30)field.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.getId());return;}
   }
  }
  if(System.currentTimeMillis()<lastScroll)return;
  if(scrolls>=15){prefs.edit().putInt("native_cursor",prefs.getInt("native_cursor",0)+1).commit();phase("search_launch","次の検索ワード・ページへ進みます");return;}
  if(swipe(nodes,root)){scrolls++;lastScroll=System.currentTimeMillis()+Timing.range(400,1800);}
  else prefs.edit().putString("status","検索結果の商品名と価格を読み取れません。診断と検索結果画面を確認してください").apply();
 }
 private String label(AccessibilityNodeInfo n){return n.getText()!=null?n.getText().toString().trim():n.getContentDescription()!=null?n.getContentDescription().toString().trim():"";}
 private void collect(AccessibilityNodeInfo n,List<AccessibilityNodeInfo> out){if(n==null||out.size()>1500)return;out.add(n);for(int i=0;i<n.getChildCount();i++)collect(n.getChild(i),out);}
 private boolean contains(List<AccessibilityNodeInfo> nodes,String token){for(AccessibilityNodeInfo n:nodes)if(n.isVisibleToUser()&&!n.isEditable()&&label(n).contains(token))return true;return false;}
 private AccessibilityNodeInfo exact(List<AccessibilityNodeInfo> nodes,String... labels){Set<AccessibilityNodeInfo> found=new HashSet<>();for(AccessibilityNodeInfo n:nodes)if(n.isVisibleToUser())for(String s:labels)if(s.equals(label(n))){AccessibilityNodeInfo c=n;for(int i=0;c!=null&&i<5;i++,c=c.getParent())if(c.isClickable()&&c.isEnabled()){found.add(c);break;}}return found.size()==1?found.iterator().next():null;}
 private boolean swipe(List<AccessibilityNodeInfo> nodes,AccessibilityNodeInfo root){
  android.graphics.Rect screen=new android.graphics.Rect();root.getBoundsInScreen(screen);
  android.graphics.Rect best=null;long area=0;
  for(AccessibilityNodeInfo n:nodes)if(n.isVisibleToUser()&&n.isScrollable()){
   android.graphics.Rect b=new android.graphics.Rect();n.getBoundsInScreen(b);
   if(!b.intersect(screen)||b.height()<300||b.width()<120)continue;
   long a=(long)b.width()*b.height();if(a>area){area=a;best=b;}
  }
  if(best==null)return false;
  float x=best.left+best.width()/2f;
  float start=best.top+best.height()*0.75f;
  float distance=best.height()*(Timing.range(250,450)/1000f);
  android.graphics.Path path=new android.graphics.Path();path.moveTo(x,start);path.lineTo(x,start-distance);
  android.accessibilityservice.GestureDescription gesture=new android.accessibilityservice.GestureDescription.Builder()
   .addStroke(new android.accessibilityservice.GestureDescription.StrokeDescription(path,0,Timing.range(250,650))).build();
  gesturePending=true;
  boolean accepted=dispatchGesture(gesture,new GestureResultCallback(){
   @Override public void onCompleted(android.accessibilityservice.GestureDescription g){gesturePending=false;}
   @Override public void onCancelled(android.accessibilityservice.GestureDescription g){gesturePending=false;if(prefs.getBoolean("running",false))stop("スクロールが中断されたため停止しました");}
  },handler);
  if(!accepted)gesturePending=false;
  return accepted;
 }
 private void tick() throws Exception {
  if(!prefs.getBoolean("running",false)){releaseScreen();return;}
  PowerManager power=(PowerManager)getSystemService(POWER_SERVICE);android.app.KeyguardManager keyguard=(android.app.KeyguardManager)getSystemService(KEYGUARD_SERVICE);
  if(!power.isInteractive()||keyguard.isKeyguardLocked()){stop("画面ロックで停止しました");return;}keepScreen(power);
  if(System.currentTimeMillis()>prefs.getLong("deadline",0)){stop("画面確認がタイムアウトしました。診断を確認してください");return;}if(gesturePending)return;
  String p=prefs.getString("phase","search_launch");boolean publish=prefs.getBoolean("publish",false);
  int limit=prefs.getInt("native_limit",0),count=prefs.getInt("session_attempts",0);
  if(publish&&limit>0&&count>=limit&&!p.equals("result")){stop("設定した件数まで処理しました");return;}
  if(p.equals("interval")){long left=prefs.getLong("wait_until",0)-System.currentTimeMillis();if(left>0){prefs.edit().putString("status","次の商品まで約"+((left+999)/1000)+"秒。停止・画面ロックで終了します").apply();return;}phase("search_launch","次の商品を探します");return;}
  if(p.equals("search_launch")){searchLaunch();return;}
  AccessibilityNodeInfo root=getRootInActiveWindow();if(root==null)return;String pkg=root.getPackageName()==null?"":root.getPackageName().toString();
  if(!pkg.equals("jp.co.rakuten.android")&&!pkg.equals("com.rakuten.room")){prefs.edit().putString("diagnostic","対象アプリの外に移動しました："+pkg+"\n処理段階："+p).apply();return;}
  List<AccessibilityNodeInfo> nodes=new ArrayList<>();collect(root,nodes);
  for(AccessibilityNodeInfo n:nodes)if(n.isPassword()){stop("本人のログイン操作が必要です");return;}
  if(contains(nodes,"認証コード")||contains(nodes,"私はロボットではありません")){stop("本人の追加認証が必要です");return;}
  int visibleEditorCount=0;for(AccessibilityNodeInfo n:nodes)if(n.isVisibleToUser()&&n.isEditable())visibleEditorCount++;
  prefs.edit().putString("diagnostic","段階："+p+"\n画面："+pkg+"\n検索語："+searchWord+"\n入力欄："+visibleEditorCount+"\n投稿操作数："+count).apply();
  if(p.equals("search_results")){if(pkg.equals("jp.co.rakuten.android"))choose(nodes,root);return;}
  JSONObject item=new JSONObject(prefs.getString("current_native","{}"));String url=item.getString("url"),keyword=item.getString("keyword"),comment=item.getString("comment");
  boolean duplicateDialog=contains(nodes,"この商品は投稿済みです");
  if(DuplicatePolicy.shouldHandle(p,pkg,verified,duplicateDialog)){
   AccessibilityNodeInfo cancel=exact(nodes,"キャンセル");if(cancel==null){stop("投稿済み確認画面を閉じられません");return;}
   if(!prefs.edit().putString("attempt:"+url,"already_posted").putString("phase","duplicate_closing").putLong("deadline",System.currentTimeMillis()+15000).commit()){stop("履歴保存失敗");return;}
   if(!cancel.performAction(AccessibilityNodeInfo.ACTION_CLICK))stop("投稿済み画面を閉じられません");return;
  }
  if(p.equals("duplicate_closing")){if(pkg.equals("com.rakuten.room")&&!duplicateDialog)advance();return;}
  if(p.equals("market")){
   if(!pkg.equals("jp.co.rakuten.android"))return;if(!verified&&contains(nodes,"商品詳細")&&contains(nodes,keyword))verified=true;
   AccessibilityNodeInfo share=exact(nodes,"ROOMに投稿");if(share!=null&&verified){phase("compose","ROOMの商品投稿画面へ進みます");if(!share.performAction(AccessibilityNodeInfo.ACTION_CLICK))stop("ROOMボタンを操作できません");return;}
   if(System.currentTimeMillis()<lastScroll)return;if(scrolls>=20){stop("商品名・ROOMボタンを確認できません");return;}
   if(swipe(nodes,root)){scrolls++;lastScroll=System.currentTimeMillis()+Timing.range(400,1800);}return;
  }
  if(p.equals("compose")){
   if(!pkg.equals("com.rakuten.room"))return;
   if(!contains(nodes,"商品投稿")||!contains(nodes,"商品紹介")||!contains(nodes,"商品画像")){
    prefs.edit().putString("status","ROOMの商品投稿画面への移動待ち。ホーム画面では入力しません").apply();return;
   }
   if(!contains(nodes,keyword)){prefs.edit().putString("status","投稿画面で対象の商品名を確認中").apply();return;}
   List<AccessibilityNodeInfo> editors=new ArrayList<>();
   for(AccessibilityNodeInfo n:nodes)if(n.isVisibleToUser()&&n.isEditable()&&n.isEnabled())editors.add(n);
   if(editors.size()!=1){prefs.edit().putString("status","商品紹介の入力欄を確認中："+editors.size()+"件").apply();return;}
   AccessibilityNodeInfo editor=editors.get(0);
   if(comment.length()>500){stop("紹介文が500文字を超えています。定型文を短くしてください");return;}
   // 投稿 is disabled until a comment is entered. Fill before looking for an enabled submit button.
   if(!comment.equals(label(editor))){
    Bundle args=new Bundle();args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,comment);
    if(!editor.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT,args)){stop("商品紹介を入力できません");return;}
    prefs.edit().putString("status","商品紹介を入力しました。内容の一致を確認中").apply();return;
   }
   if(!publish){stop("プレビュー完了。商品紹介を入力しました。公開していません");return;}
   AccessibilityNodeInfo submit=exact(nodes,"投稿");
   if(submit==null){prefs.edit().putString("status","紹介文の一致を確認。右上の投稿ボタンが有効になるまで待っています").apply();return;}
   if(prefs.contains("attempt:"+url)){stop("処理履歴があるため再投稿しません");return;}
   if(!prefs.edit().putString("attempt:"+url,"submission_attempted").putString("phase","result").putInt("session_attempts",prefs.getInt("session_attempts",0)+1).putLong("deadline",System.currentTimeMillis()+20000).commit()){stop("履歴保存失敗");return;}
   if(!submit.performAction(AccessibilityNodeInfo.ACTION_CLICK))stop("投稿操作を確認できません。結果をROOMで確認してください");
  }
 }
 @Override public void onAccessibilityEvent(AccessibilityEvent e){
  if(prefs==null||!prefs.getBoolean("running",false)||!"result".equals(prefs.getString("phase",""))||!"com.rakuten.room".contentEquals(e.getPackageName()==null?"":e.getPackageName()))return;
  if(!e.getText().toString().matches("(?s).*投稿(が)?(完了しました|しました).*"))return;
  try{String id=new JSONObject(prefs.getString("current_native","{}")).getString("url");if(!prefs.edit().putString("attempt:"+id,"success_message_observed").commit()){stop("結果保存失敗");return;}advance();}catch(Exception ex){stop("結果確認エラー");}
 }
 @Override public void onInterrupt(){if(prefs!=null)stop("操作サービスが中断されました");}
 @Override public void onDestroy(){handler.removeCallbacksAndMessages(null);if(prefs!=null)stop("操作サービス終了");super.onDestroy();}
}
