package jp.roomhelper;

final class NativeCandidate {
    static boolean looksLikeTitle(String name,String word) {
        if(name==null||name.length()<12||name.length()>400||!name.contains(word))return false;
        return !name.contains("検索結果") && !name.contains("検索する") && !name.contains("キーワードから探す") &&
            !name.contains("寄付を申し込む") && !name.contains("購入手続き") && !name.contains("楽天ポイントの獲得") && !name.contains("レビューを書く");
    }
    static String identifier(String name) { return name.substring(0,Math.min(32,name.length())); }
    static String normalize(String text) { return java.text.Normalizer.normalize(text,java.text.Normalizer.Form.NFKC).replaceAll("[\\s\\p{P}\\p{S}]", ""); }
    static java.util.List<String> anchors(String title,String word) {
        String cleaned=java.text.Normalizer.normalize(title,java.text.Normalizer.Form.NFKC).replaceAll("[【\\[].*?[】\\]]", " ");
        java.util.List<String> anchors=new java.util.ArrayList<>();
        for(String token:cleaned.split("[\\s\\p{P}\\p{S}0-9]+")){
            if(token.length()<3||token.equals(word)||token.matches(".*(?:総合|ランキング|高評価|送料無料|選べる|定期便|人気|レビュー|ふるさと納税|ポイント|獲得|発送|内容量).*"))continue;
            if(!anchors.contains(token))anchors.add(token);if(anchors.size()>=6)break;
        }
        return anchors;
    }
    static boolean matchesProduct(String screen,String title,String word) {
        String normalized=normalize(screen),prefix=normalize(identifier(title));
        if(prefix.length()>=8&&normalized.contains(prefix))return true;
        java.util.List<String> tokens=anchors(title,word);if(tokens.isEmpty())return false;
        int count=0;for(String token:tokens)if(normalized.contains(normalize(token)))count++;
        return count>=Math.min(2,tokens.size());
    }
    static boolean isPrice(String text) {
        return text!=null && text.matches("(?s).*(?:[¥￥]\\s*[0-9,]+|[0-9,]+\\s*円).*");
    }
    static boolean sameRow(int titleLeft,int titleTop,int titleBottom,int priceLeft,int priceTop,int allowance) {
        return priceLeft>=titleLeft-32 && priceTop>=titleTop-16 && priceTop<=titleBottom+allowance;
    }
    static String comment(String template,String word) {
        String result=template.contains("{keyword}")?template.replace("{keyword}",word):word+"はこちら！\n"+template;
        if(result.length()>500)throw new IllegalArgumentException("検索ワード付きの紹介文が500文字を超えています");
        return result;
    }
    static String id(String name) {
        try {
            byte[] bytes=java.security.MessageDigest.getInstance("SHA-256").digest(name.trim().replaceAll("\\s+"," ").getBytes("UTF-8"));
            StringBuilder out=new StringBuilder("native:");for(byte b:bytes)out.append(String.format(java.util.Locale.ROOT,"%02x",b&255));return out.toString();
        }catch(Exception e){throw new IllegalStateException(e);}
    }
}
