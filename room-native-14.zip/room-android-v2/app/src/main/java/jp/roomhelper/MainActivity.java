package jp.roomhelper;
import android.app.*;
import android.content.*;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.widget.*;
import org.json.*;
public class MainActivity extends Activity {
 private android.content.SharedPreferences prefs;private TextView status;
 private final Handler handler=new Handler(Looper.getMainLooper());
 private final Runnable refresh=new Runnable(){public void run(){status.setText("ROOMキュー 1.4・API不要版\n"+prefs.getString("status","検索ワードと固定文を設定して開始してください"));handler.postDelayed(this,1000);}};
 @Override public void onCreate(Bundle b){super.onCreate(b);prefs=getSharedPreferences("native_queue",0);LinearLayout root=new LinearLayout(this);root.setOrientation(1);root.setPadding(24,24,24,24);ScrollView scroll=new ScrollView(this);scroll.addView(root);setContentView(scroll);status=new TextView(this);root.addView(status);
  TextView help=new TextView(this);help.setText("楽天市場アプリ内で検索 → 商品を選ぶ → ROOMに投稿。API登録・APIキー・AIは使いません。\n開始時だけ動作し、停止や画面ロックで終了します。実機の検索結果画面への対応は未確認です。");root.addView(help);
  button(root,"検索ワード・固定文",this::editNative);
  button(root,"待ち時間",this::editInterval);
  button(root,"ユーザー補助の設定",()->{stop();startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));});
  button(root,"ROOMアプリを開く",()->{stop();Intent i=getPackageManager().getLaunchIntentForPackage("com.rakuten.room");if(i!=null)startActivity(i);else say("公式ROOMアプリを入れてください");});
  button(root,"プレビュー（公開しない）",()->begin(false));
  button(root,"連続投稿を開始",()->new AlertDialog.Builder(this).setTitle("固定文で連続投稿")
   .setMessage("検索結果から商品を選んで固定文で公開します。本人の公式ROOMアカウント・検索ワード・固定文を確認してください。上限0の場合は候補がある間、停止するまで継続します。")
   .setPositiveButton("開始",(d,w)->begin(true)).setNegativeButton("戻る",null).show());
  button(root,"停止",this::stop);button(root,"止まった理由・診断",()->new AlertDialog.Builder(this).setTitle("診断").setMessage(prefs.getString("diagnostic","まだ診断はありません")+"\n現在："+prefs.getString("status","")).setPositiveButton("閉じる",null).show());
 }
 private void button(LinearLayout root,String label,Runnable action){Button b=new Button(this);b.setText(label);root.addView(b);b.setOnClickListener(v->action.run());}
 private void say(String s){prefs.edit().putString("status",s).apply();status.setText(s);}
 private void stop(){prefs.edit().putBoolean("running",false).putString("status","停止しました。クリック済みの結果はROOMで確認してください").commit();}
 private void editNative(){stop();LinearLayout box=new LinearLayout(this);box.setOrientation(1);box.setPadding(20,20,20,20);ScrollView container=new ScrollView(this);container.addView(box);
  String[] labels={"検索ワード（1行1つ）","固定文（{keyword}＝検索ワード、500文字まで）","1回の上限（0＝停止まで継続、1〜1000）"};EditText[] fields=new EditText[3];
  for(int i=0;i<3;i++){TextView label=new TextView(this);label.setText(labels[i]);box.addView(label);fields[i]=new EditText(this);box.addView(fields[i]);}
  fields[0].setMinLines(3);fields[0].setText(prefs.getString("native_words","ふるさと納税\n日用品\nスイーツ"));
  fields[1].setMinLines(3);fields[1].setText(prefs.getString("native_comment","{keyword}はこちら！\n#楽天市場 #お買い物"));fields[2].setInputType(2);fields[2].setText(String.valueOf(prefs.getInt("native_limit",0)));
  new AlertDialog.Builder(this).setTitle("API不要の検索設定").setView(container).setPositiveButton("保存",(d,w)->{try{
   String words=fields[0].getText().toString().trim(),comment=fields[1].getText().toString().trim();String[] list=words.split("\\n");int limit=Integer.parseInt(fields[2].getText().toString());
   if(list.length<1||list.length>10||comment.isEmpty()||comment.length()>500||limit<0||limit>1000)throw new Exception();
   for(String word:list)if(word.trim().isEmpty()||word.length()>60)throw new Exception();
   prefs.edit().putString("native_words",words).putString("native_comment",comment).putInt("native_limit",limit).putInt("native_cursor",0).apply();say("検索ワードと固定文を保存しました");
  }catch(Exception e){say("検索ワード・固定文・上限件数を確認してください");}}).setNegativeButton("戻る",null).show();
 }
 private void editInterval(){stop();LinearLayout box=new LinearLayout(this);box.setOrientation(1);TextView help=new TextView(this);help.setText("秒数は小数3桁まで入力可能。商品間は0.1〜3600秒、操作間は0.1〜10秒。スクロール距離・時間も毎回変わります。");box.addView(help);
  EditText[] fields=new EditText[4];String[] labels={"次の商品まで：最短秒","次の商品まで：最長秒","操作間：最短秒","操作間：最長秒"};
  int[] values={prefs.getInt("min_wait_ms",prefs.getInt("min_wait",60)*1000),prefs.getInt("max_wait_ms",prefs.getInt("max_wait",180)*1000),prefs.getInt("op_min_ms",400),prefs.getInt("op_max_ms",1800)};
  for(int i=0;i<4;i++){TextView label=new TextView(this);label.setText(labels[i]);box.addView(label);fields[i]=new EditText(this);fields[i].setInputType(android.text.InputType.TYPE_CLASS_NUMBER|android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);fields[i].setText(new java.math.BigDecimal(values[i]).divide(new java.math.BigDecimal(1000)).toPlainString());box.addView(fields[i]);}
  new AlertDialog.Builder(this).setTitle("ランダム待ち時間").setView(box).setPositiveButton("保存",(d,w)->{try{
   int[] v=new int[4];for(int i=0;i<4;i++)v[i]=Timing.millis(fields[i].getText().toString());
   if(v[0]<100||v[1]<v[0]||v[1]>3600000||v[2]<100||v[3]<v[2]||v[3]>10000)throw new Exception();
   prefs.edit().putInt("min_wait_ms",v[0]).putInt("max_wait_ms",v[1]).putInt("op_min_ms",v[2]).putInt("op_max_ms",v[3]).apply();say("待ち時間を保存しました");
  }catch(Exception e){say("最短≦最長、小数3桁まで、指定範囲内で入力してください");}}).setNegativeButton("戻る",null).show();
 }
 private void begin(boolean publish){stop();android.view.accessibility.AccessibilityManager am=(android.view.accessibility.AccessibilityManager)getSystemService(ACCESSIBILITY_SERVICE);boolean enabled=false;for(android.accessibilityservice.AccessibilityServiceInfo s:am.getEnabledAccessibilityServiceList(android.accessibilityservice.AccessibilityServiceInfo.FEEDBACK_ALL_MASK))if(s.getResolveInfo().serviceInfo.packageName.equals(getPackageName())&&s.getResolveInfo().serviceInfo.name.endsWith("NativePostService"))enabled=true;
  if(!enabled){say("ユーザー補助でROOMキューを有効にしてください");return;}
  if(getPackageManager().getLaunchIntentForPackage("com.rakuten.room")==null||getPackageManager().getLaunchIntentForPackage("jp.co.rakuten.android")==null){say("公式楽天市場・ROOMアプリが必要です");return;}
  prefs.edit().putBoolean("publish",publish).putBoolean("running",true).putString("phase","search_launch").putLong("deadline",System.currentTimeMillis()+90000).putInt("session_attempts",0).putInt("native_cursor",0).putString("status","検索から開始します").commit();
 }
 @Override protected void onResume(){super.onResume();handler.post(refresh);}
 @Override protected void onPause(){handler.removeCallbacks(refresh);super.onPause();}
}
