public class CandidateTest {
 public static void main(String[] args){
  if(!NativeCandidate.looksLikeTitle("【ふるさと納税】ハンバーグ20個セット", "ふるさと納税"))throw new AssertionError("product title");
  for(String s:new String[]{"ふるさと納税の検索結果はこちら", "ふるさと納税の寄付を申し込む", "ふるさと納税検索する", "日用品"})if(NativeCandidate.looksLikeTitle(s,s.contains("ふるさと")?"ふるさと納税":"日用品"))throw new AssertionError("not a product");
  if(!NativeCandidate.id("商品 A").equals(NativeCandidate.id("商品  A")))throw new AssertionError("duplicate normalization");
  if(NativeCandidate.id("商品 A").equals(NativeCandidate.id("商品 B")))throw new AssertionError("distinct candidates");
  if(!NativeCandidate.id("商品 A").matches("native:[0-9a-f]{64}"))throw new AssertionError("history key");
  if(NativeCandidate.identifier("abcdefghijklmnopqrstuvwxyz1234567890").length()!=32)throw new AssertionError("identifier length");
  System.out.println("6 candidate-policy checks passed");
 }
}


final class NativeCandidate {
    static boolean looksLikeTitle(String name,String word) {
        if(name==null||name.length()<12||name.length()>400||!name.contains(word))return false;
        return !name.contains("検索結果") && !name.contains("検索する") && !name.contains("キーワードから探す") &&
            !name.contains("寄付を申し込む") && !name.contains("購入手続き") && !name.contains("楽天ポイントの獲得") && !name.contains("レビューを書く");
    }
    static String identifier(String name) { return name.substring(0,Math.min(32,name.length())); }
    static String id(String name) {
        try {
            byte[] bytes=java.security.MessageDigest.getInstance("SHA-256").digest(name.trim().replaceAll("\\s+"," ").getBytes("UTF-8"));
            StringBuilder out=new StringBuilder("native:");for(byte b:bytes)out.append(String.format(java.util.Locale.ROOT,"%02x",b&255));return out.toString();
        }catch(Exception e){throw new IllegalStateException(e);}
    }
}
